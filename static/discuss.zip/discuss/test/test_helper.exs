ExUnit.start

Ecto.Adapters.SQL.Sandbox.mode(Discuss.Repo, :manual)

