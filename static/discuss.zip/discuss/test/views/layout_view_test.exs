defmodule Discuss.LayoutViewTest do
  use Discuss.ConnCase, async: true
end
