defmodule Discuss.PageViewTest do
  use Discuss.ConnCase, async: true
end
