defmodule Discuss.AuthController do
  use Discuss.Web, :controller
  plug Ueberauth

  # Just type 'User' instead of 'Discuss.User'
  alias Discuss.User

  def callback(conn, _params) do
    # Pull the 'auth' struct off the connection.
    %{assigns: %{ueberauth_auth: auth}} = conn
    user_params = %{
      token: auth.credentials.token,
      email: auth.info.email,
      provider: Atom.to_string(auth.provider)
    }

    IO.inspect(user_params)

    # Make our changeset:
    changeset = User.changeset(%User{}, user_params)

    # TODO: Insert records.
    signin(conn, changeset)

    conn
    |> put_flash(:info, "Welcome back!")
    |> redirect(to: topic_path(conn, :index))
  end

  defp insert_or_update_user(changeset) do
    # If this returns nil, we should add the user, otherwise it'll return a user
    case Repo.get_by(User, email: changeset.changes.email) do
      nil -> Repo.insert(changeset)
      user -> {:ok, user}  # (same return format as repo.get_by)
    end
  end

  defp signin(conn, changeset) do
    case insert_or_update_user(changeset) do
      {:ok, user} ->
        conn
        |> put_flash(:info, "Welcome back! (You are logged in.)")
        |> put_session(:user_id, user.id)  # we add the user ID to the session.
        |> redirect(to: topic_path(conn, :index))
        # Now the user is 'logged in'.
      {:error, reason } ->
        IO.inspect(reason)
        conn
        |> put_flash(:error, "Failed to sign in.")
        |> redirect(to: topic_path(conn, :index))
    end
  end

  def signout(conn, _params) do
    conn
    # My guess: |> put_session(:user_id, nil)
    # This instead drops all session data:
    |> configure_session(drop: true)
    |> redirect(to: topic_path(conn, :index))
  end
end
