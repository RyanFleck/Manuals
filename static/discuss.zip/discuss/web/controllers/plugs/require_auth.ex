defmodule Discuss.Plugs.RequireAuth do
  import Plug.Conn  # gives halt
  import Phoenix.Controller  # gives put_flash and redirect

  alias Discuss.Router.Helpers

  def init(_params) do
  end

  def call(conn, _params) do
    # If you are signed in, carry on, else go home
    if conn.assigns[:user] do
      conn  # returning the conn object is how you end a plug
    else
      conn
      |> put_flash(:error, "You must be logged in to do that.")
      # Use 'Helpers'
      |> redirect(to: Helpers.topic_path(conn, :index))
      |> halt()  # SEND IT BACK NOW. From Plug.Conn
      # halt: plugs can end a connection before they get to the controller
    end
  end
end
