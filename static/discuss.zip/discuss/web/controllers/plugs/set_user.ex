defmodule Discuss.Plugs.SetUser do
  import Plug.Conn
  import Phoenix.Controller

  alias Discuss.Repo
  alias Discuss.User

  # A plug module must define init and call functions

  def init(_params) do
  end

  def call(conn, _params) do

    # get_session comes from Phoenix.Controller
    user_id = get_session(conn, :user_id)

    # Cond implicitly returns a connection
    #  with or without a user attached
    cond do
      user = user_id && Repo.get(User, user_id) ->
        # assign is a helper to update the assigns struct
        # assign comes from Plug.Conn
        assign(conn, :user, user)
      true ->
        assign(conn, :user, nil)
    end
  end
end
