defmodule Discuss.TopicController do
  use Discuss.Web, :controller
  alias Discuss.Topic

  plug Discuss.Plugs.RequireAuth when
    action in [:new, :create, :edit, :update, :delete]

  plug :check_post_owner when
    action in [:update, :edit, :delete]

  def index(conn, _params) do
    # Render a list of all the topics in the database.
    # If unaliased, Discuss.Repo.all(Discuss.Topic)
    IO.inspect(conn.assigns)
    render conn, "index.html", topics: Repo.all(Topic)
  end

  def show(conn, %{"id" => topic_id}) do
    topic = Repo.get!(Topic, topic_id)
    render conn, "show.html", topic: topic
  end

  def new(conn, _params) do
    changeset = Topic.changeset(%Topic{}, %{})
    render conn, "new.html", changeset: changeset
  end

  def create(conn, %{"topic" => topic}) do
    # current user is conn.assigns[:user] or conn.assigns.user
    # old:  changeset = Topic.changeset(%Topic{}, topic)
    changeset = conn.assigns.user
    |> build_assoc(:topics)
    |> Topic.changeset(topic)

    case Repo.insert(changeset) do
      {:ok, _post} ->
        conn
        |> put_flash(:info, "Topic Created")
        |> redirect(to: topic_path(conn, :index))
      {:error, err_changeset} -> render conn, "new.html", changeset: err_changeset
    end
  end

  def edit(conn, %{"id" => topic_id}) do
    # Load an existing/complete 'changeset' from the database.
    topic = Repo.get!(Topic, topic_id)
    changeset = Topic.changeset(topic)
    # Send it out, bound to a new template we'll make now
    render conn, "edit.html", changeset: changeset, topic: topic
  end

  def update(conn, %{"topic" => topic, "id" => id}) do
    # We fetch the original record from the repository first? Ok.
    old_topic = Repo.get!(Topic, id)
    changeset = Topic.changeset(old_topic, topic)
    # Push the update to the database:
    case Repo.update(changeset) do
      {:ok, _topic} ->
        conn
        |> put_flash(:info, "Topic Updated")
        |> redirect(to: topic_path(conn, :index))
      {:error, err_changeset} ->
        render conn, "edit.html",
          changeset: err_changeset, topic: old_topic
    end
  end

  def delete(conn, %{"id" => topic_id}) do
    Repo.get!(Topic, topic_id) |> Repo.delete!
    conn
    |> put_flash(:info, "Topic Deleted")
    |> redirect(to: topic_path(conn, :index))
  end

  # FUNCTION PLUG
  def check_post_owner(conn, _params) do
    # If the post has the same user_id as the user, pass, otherwise halt
    %{params: %{"id" => topic_id}} = conn

    if Repo.get(Topic, topic_id).user_id == conn.assigns.user.id do
      conn
    else
      conn
      |> put_flash(:error, "You do not own that resource.")
      |> redirect(to: topic_path(conn, :index))
      |> halt()
    end
  end
end
