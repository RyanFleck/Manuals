defmodule Discuss.LayoutView do
  use Discuss.Web, :view
end
